import 'package:flutter/material.dart';

class Screen3 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Screen 3')),
      body: Center(
          child: Text('This is Screen 3', style: TextStyle(fontSize: 24))),
    );
  }
}
