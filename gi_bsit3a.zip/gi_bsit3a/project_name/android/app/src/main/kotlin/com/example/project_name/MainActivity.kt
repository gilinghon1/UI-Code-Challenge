package com.example.project_name

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
