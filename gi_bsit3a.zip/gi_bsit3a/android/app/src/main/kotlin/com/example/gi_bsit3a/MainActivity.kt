package com.example.gi_bsit3a

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
